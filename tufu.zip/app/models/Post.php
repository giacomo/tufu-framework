<?php

namespace App\Model;

use Tufu\Core\Model;

class Post extends Model
{
    protected $fillable = ['title', 'description'];

}
